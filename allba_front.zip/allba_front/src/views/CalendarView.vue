<template>
    <div>
        hi calendar
        <!-- <router-link to="/calender">calender</router-link> -->
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    
</style>